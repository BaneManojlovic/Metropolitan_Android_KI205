package com.metorpolitan.domacizadatak31;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import static android.app.PendingIntent.getActivity;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WindowManager wm = getWindowManager();
        Display d = wm.getDefaultDisplay();

        DisplayMetrics displaymetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(displaymetrics);
        int screenWidth = displaymetrics.widthPixels;
        int screenHeight = displaymetrics.heightPixels;


        if (screenWidth > screenHeight) {
        //---prelazak u landscape mode---
            Toast.makeText(this, "LANDSKAPE", Toast.LENGTH_LONG).show();
        }
        else {
        //--- prelazak u portrait mode---
            Toast.makeText(this, "PORTRAIT", Toast.LENGTH_LONG).show();
        }
    }


    //KLIK NA PRVO DUGME INICIRA OVU METODU I PRIKAZUJE TOAST PORUKU SA IMENOM NASEG UNIVERZITETA.
    public void onClick1(View view) {
        Toast.makeText(this, "UNIVERZITET METROPOLITAN!", Toast.LENGTH_LONG).show();
    }


    //metoda koja omogucava otvaranje google maps aplikacije na lokaciji univerziteta metropolitan.
    public void onClick2(View view) {
//        Intent i = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("geo: 44.830572, 20.454743"));
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:44.830572,20.454743?q=44.830572,20.454743(Univerzitet+Metropolitan)"));
        startActivity(intent);
    }


}
