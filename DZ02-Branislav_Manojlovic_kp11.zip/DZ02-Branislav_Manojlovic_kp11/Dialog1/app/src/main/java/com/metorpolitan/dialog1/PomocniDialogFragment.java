package com.metorpolitan.dialog1;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

public class PomocniDialogFragment extends DialogFragment {

    //konstruktor
    public PomocniDialogFragment(){

    }

    public static PomocniDialogFragment newInstance(String title) {
        PomocniDialogFragment frag = new PomocniDialogFragment();
        Bundle args = new Bundle();
        args.putString("Izbor opcije:", title);

        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pomocni_dialog_fragment, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Fetch arguments from bundle and set title
        String title = getArguments().getString("Izbor opcije:", "Enter Name");
        getDialog().setTitle(title);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}