package com.metorpolitan.dialog1;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    CharSequence[] items = {"FIT", "Fakultet za menadzment", "Fakultet digitalnih umetnosti"};
    boolean[] itemsChecked = new boolean[items.length];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    private void showDialogPomocniFragment() {
        FragmentManager fm = getSupportFragmentManager();
        PomocniDialogFragment editNameDialogFragment = PomocniDialogFragment.newInstance("Some Title");
        editNameDialogFragment.show(fm, "pomocni_dialog_fragment");
    }


    public void onClick(View view) {
       showDialogPomocniFragment();
    }

    //Metoda koja pokrece dijalog progresa
    public void onClick2(View view) throws InterruptedException {
        final ProgressDialog dialog = ProgressDialog.show(this, "Nesto se desava.", "Sacekajte...", true);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(5000);
                    dialog.dismiss();
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }).start();
    }

    //Metoda za prikaz dijaloga progresa preuzimanja
    public void onClick3(View view) {
        final ProgressDialog dialog = ProgressDialog.show(this, "Preuzimanje sadrzaja", "1, 2, ...");
        new Thread(new Runnable() {

            public void run() {
                    try {
                        //---simulacija da nešto radi---
                        Thread.sleep(1000);
                        dialog.dismiss();
                        //---osvežavanje dijaloga---
                        //progressBar.incrementProgressBy((100 / 15));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
            }
        }).start();
    }

    //Metode koje se pozivaju kada se selektuje opcija-zeljeno radio dugme
    public void izborOpcije1(View view) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("http://www.metropolitan.ac.rs/osnovne-studije/fakultet-informacionih-tehnologija/"));
        startActivity(intent);
    }

    public void izbroOpcije2(View view) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("http://www.metropolitan.ac.rs/osnovne-studije/fakultet-za-menadzment/"));
        startActivity(intent);
    }

    public void izbroOpcije3(View view) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("http://www.metropolitan.ac.rs/fakultet-digitalnih-umetnosti-2/"));
        startActivity(intent);
    }
}