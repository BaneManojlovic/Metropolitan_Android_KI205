package com.metorpolitan.domacizadatak32;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button buttonOK;
    Button buttonNE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        changeTextPozitivno();
        changeTextNegativno();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.opcijaFIT:
                buttonOK.setEnabled(true);
                buttonNE.setEnabled(true);
                return true;

            case R.id.opcijaFAM:
                buttonOK.setEnabled(true);
                buttonNE.setEnabled(true);
                return true;

            case R.id.opcijaFDU:
                buttonOK.setEnabled(true);
                buttonNE.setEnabled(true);
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    public void onClick1(MenuItem item) {
        final TextView changingText = (TextView) findViewById(R.id.textView);
        changingText.setText("Da li studirate FIT?");
    }

    public void onClick2(MenuItem item) {
        final TextView changingText = (TextView) findViewById(R.id.textView);
        changingText.setText("Da li studirate FAM?");
    }

    public void onClick3(MenuItem item) {
        final TextView changingText = (TextView) findViewById(R.id.textView);
        changingText.setText("Da li studirate FDU?");
    }

    public void changeTextPozitivno(){
        final TextView changingText = (TextView) findViewById(R.id.textView);
        buttonOK = (Button) findViewById(R.id.buttonYes);
        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changingText.setText("Svaka cast!!!");
            }
        });
    }

    public void changeTextNegativno(){
        final TextView changingText = (TextView) findViewById(R.id.textView);
        buttonNE = (Button) findViewById(R.id.buttonNo);
        buttonNE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changingText.setText("Steta!!!");
            }
        });
    }
}