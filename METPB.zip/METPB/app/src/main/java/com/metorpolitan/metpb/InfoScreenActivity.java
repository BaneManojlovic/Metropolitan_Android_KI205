package com.metorpolitan.metpb;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class InfoScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_screen);


    }


    public void onClickSend(View view) {

        if(isConnectedToInternet())
        {
            String[] primalac = {"bane1manojlovic@gmail.com"};
            Intent sentIntent = new Intent(Intent.ACTION_SEND);
            sentIntent.setType("text/plain");
            sentIntent.putExtra(Intent.EXTRA_EMAIL, primalac);
            sentIntent.putExtra(Intent.EXTRA_SUBJECT, "Email subject");
            sentIntent.putExtra(Intent.EXTRA_TEXT, "Body of Email");
            startActivity(sentIntent);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }

    }

    //proverava da li postoji konekcija sa internetom
    public boolean isConnectedToInternet(){
        ConnectivityManager connectivity = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }

        }
        return false;
    }
}
