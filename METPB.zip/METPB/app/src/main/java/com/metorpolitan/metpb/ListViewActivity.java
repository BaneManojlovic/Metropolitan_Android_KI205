package com.metorpolitan.metpb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ListViewActivity extends AppCompatActivity {

    String[] listaPredmeta = {"Matematika I", "Matematika II", "Matematicka Statistika", "Operaciona Istrazivanja", "Mehanika I", "Mehanika II", "Meahanizmi",
    "Spedicija", "Poznavanje Robe u Transportu", "Osnove PTT Saobracaja", "Osnove Drumskog Saobracaja", "Osnove Zeleznickog Saobracaja", "Osnove Vazduhoplovnog Saobracaja",
    "Osnove Telekomunikacija", "Sistemi", "Signali", "Digitalne Komunikacije", "Digitalne Modulacije", "Opticke Telekomunikacije", "Digitalna Obrada Signala",
            "Uvod u Teoriju Informacija","Teorija Informacija i Komunikacija", "Tehnike Kodovanja", "Osnove Radio Komunikacija", "Mobilne Komunikacije"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.lista, listaPredmeta);
        ListView listView = (ListView) findViewById(R.id.predmeti_lista);
        listView.setAdapter(adapter);
    }
}
