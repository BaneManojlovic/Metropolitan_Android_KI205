package com.metorpolitan.metpb;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class PregledActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pregled);
    }

    public void onClick11(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick12(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick13(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick14(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick15(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick16(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }
    }

    public void onClick17(View view) {
        if(isConnectedToInternet())
        {
            Intent i = new Intent("android.intent.action.VIEW");
            i.setData(Uri.parse("http://www.metropolitan.edu.rs/"));
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
        }

    }

    //proverava da li postoji konekcija sa internetom
    public boolean isConnectedToInternet(){
        ConnectivityManager connectivity = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }

        }
        return false;
    }
}
